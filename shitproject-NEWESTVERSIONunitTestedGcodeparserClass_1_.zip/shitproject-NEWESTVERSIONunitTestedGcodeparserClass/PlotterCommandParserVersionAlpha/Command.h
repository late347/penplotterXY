#pragma once
class Command {
public:
	enum  type { M1, M4, M10, G1, G28 };

	Command(type cmdtype = G28, bool islegal = false, int numberparameter = 0, int x = 0, int y = 0) {
		commandWord = cmdtype;
		isLegal = islegal;
		commandNumber = numberparameter;
		xCoord = x;
		yCoord = y;
	}
	virtual ~Command();

	void setCommandWord(type newcmdtype) { commandWord = newcmdtype; }
	void setLegality(bool newValueLegality) { isLegal = newValueLegality; }
	void setCommandNumber(int newNumberParameter) { commandNumber = newNumberParameter; }
	void setXCoord(int newx) { xCoord = newx; }
	void setYCoord(int newy) { yCoord = newy; }

	void setNewValues(type newcmdtype, bool newlegality, int newnumberparameter, int newx, int newy) {
		commandWord = newcmdtype;
		isLegal = newlegality;
		commandNumber = newnumberparameter;
		xCoord = newx;
		yCoord = newy;
	}

	enum Command::type getCommandWord() { return commandWord; }
	bool getLegality() { return isLegal; }
	int getCommandNumber() { return commandNumber; }
	int getXCoord() { return xCoord; }
	int getYCoord() { return yCoord; }

protected:
	type commandWord; //note! commandWord is an enum variable of type "type"
	bool isLegal;
	int commandNumber;
	int xCoord;
	int yCoord;
};





Command::~Command() {
}
