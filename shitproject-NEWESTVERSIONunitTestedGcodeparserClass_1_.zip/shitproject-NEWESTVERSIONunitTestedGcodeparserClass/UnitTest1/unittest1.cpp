#include "stdafx.h"
#include "CppUnitTest.h"
#include "../PlotterCommandParserVersionAlpha/CommandStruct.h"
#include "../PlotterCommandParserVersionAlpha/GcodeParser.h"
#include <string> //needed for FULL APP certainly!
#include <sstream>//maybe needed for FULL APP TODO:: confirm it later ?!?! EDITED::CAUSES FLASH MEMORY TO OVERFLOW, program too large?!?!
#include <vector>//needed for FULL APP certainly!
#include <fstream>//needed for debugging version only
#include<iostream>//needed for debugging version only

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace TestingTrue
{		
	TEST_CLASS(m1tests)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
			//create your testinputstruct here in beginning
			CommandStruct cmd{CommandStruct::M1, 0, true, 0,0};
			GcodeParser parser;

			
			CommandStruct cmdres= parser.parseCommand("M1 0");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a,b);
			parser.clearTokens();
		}

		TEST_METHOD(TestMethod2) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::M1, 1, true, 0, 0 };
			GcodeParser parser;


			CommandStruct cmdres = parser.parseCommand("M1 1");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TestMethod3) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::M1, 16, true, 0, 0 };
			GcodeParser parser;


			CommandStruct cmdres = parser.parseCommand("M1 16");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TestMethod4) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::M1, 160, true, 0, 0 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("M1 160");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}



	};


	TEST_CLASS(m4tests) {
public:
	TEST_METHOD(TestMethod1) {
		//create your testinputstruct here in beginning
		CommandStruct cmd{ CommandStruct::M4, 0, true, 0, 0 };
		GcodeParser parser;


		CommandStruct cmdres = parser.parseCommand("M4 0");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
		Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
		Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		int a = cmd.commandWord;
		int b = cmdres.commandWord;
		Assert::AreEqual(a, b);
		parser.clearTokens();
	}

	TEST_METHOD(TestMethod2) {
		//create your testinputstruct here in beginning
		CommandStruct cmd{ CommandStruct::M4, 1, true, 0, 0 };
		GcodeParser parser;


		CommandStruct cmdres = parser.parseCommand("M4 1");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
		Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
		Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		int a = cmd.commandWord;
		int b = cmdres.commandWord;
		Assert::AreEqual(a, b);
		parser.clearTokens();
	}
	TEST_METHOD(TestMethod3) {
		//create your testinputstruct here in beginning
		CommandStruct cmd{ CommandStruct::M4, 10, true, 0, 0 };
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 10");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
		Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
		Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		int a = cmd.commandWord;
		int b = cmdres.commandWord;
		Assert::AreEqual(a, b);
		parser.clearTokens();
	}
	TEST_METHOD(TestMethod4) {
		//create your testinputstruct here in beginning
		CommandStruct cmd{ CommandStruct::M4, 106, true, 0, 0 };
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 106");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
		Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
		Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		int a = cmd.commandWord;
		int b = cmdres.commandWord;
		Assert::AreEqual(a, b);
		parser.clearTokens();
	}	
	TEST_METHOD(TestMethod5) {
		//create your testinputstruct here in beginning
		CommandStruct cmd{ CommandStruct::M4, 255, true, 0, 0 };
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 255");
		//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
		Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
		Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		int a = cmd.commandWord;
		int b = cmdres.commandWord;
		Assert::AreEqual(a, b);
		parser.clearTokens();
	}
	};

	TEST_CLASS(g28tests) {
	public:
		TEST_METHOD(TEST1) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G28, 0, true, 0, 0 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G28");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
	};
	TEST_CLASS(m10Tests) {
	public:
		TEST_METHOD(TEST1) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::M10, 0, true, 0, 0 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("M10");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.commandNumber, cmdres.commandNumber);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		
		}
	};
	TEST_CLASS(g1tests) {
	public:
		TEST_METHOD(TEST1) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -50, 10150 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-0.50 Y101.50 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST2) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 14950, 10150 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X149.50 Y101.50 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST3) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 4629, 6568 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X46.29 Y65.68 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST4) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 750, 10750 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X7.50 Y107.50 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST5) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 589, 6679 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X5.89 Y66.79 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST6) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -11100, 6617 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-111.00 Y66.17 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST7) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -207, 6656 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-2.07 Y66.56 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST8) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -1323, 6683 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-13.23 Y66.83 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST9) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 11581, -16678 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X115.81 Y-166.78 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST10) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 11769, -6589 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X117.69 Y-65.89 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST11) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -12018, -16247 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-120.18 Y-162.47 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST12) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -12015, -6040 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-120.15 Y-60.40 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST13) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -1950, -5846 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-19.50 Y-58.46 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST14) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -899, -742 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-8.99 Y-7.42 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST15) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, -1, -20 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X-0.01 Y-0.20 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

		TEST_METHOD(TEST16) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 0, 0 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X0.00 Y0.00 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}
		TEST_METHOD(TEST17) {
			//create your testinputstruct here in beginning
			CommandStruct cmd{ CommandStruct::G1, 0, true, 750, 10750 };
			GcodeParser parser;
			CommandStruct cmdres = parser.parseCommand("G1 X7.50 Y107.50 A0");
			//	Assert::AreEqual(cmd.commandWord,cmdres.commandWord);
			Assert::AreEqual(cmd.xCoord, cmdres.xCoord);
			Assert::AreEqual(cmd.yCoord, cmdres.yCoord);
			Assert::AreEqual(cmd.isLegal, cmdres.isLegal);
			//NOTE
			/*to compare enum commandWords we must enforce the enums into integer first before compare
			OTHERWISE visual studio gives compiler error from the enum asserts*/
			int a = cmd.commandWord;
			int b = cmdres.commandWord;
			Assert::AreEqual(a, b);
			parser.clearTokens();
		}

	
	};


}

namespace TestingFalse {
	TEST_CLASS(M1) {
public:
	TEST_METHOD(TEST1) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" M1  0 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST2) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M1 0 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST3) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M1  0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST4) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("   M1 0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST5) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M1 0 M1 0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	
	};


	TEST_CLASS(M4) {
public:
	TEST_METHOD(TEST1) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 g45");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST2) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 -0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST3) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" M4 28 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST4) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4  33");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST5) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M4 38   ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST6) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" M4 43");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST7) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("   M4 48");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST8) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	};
	
	
	TEST_CLASS(M10) {
public:
	TEST_METHOD(TEST1) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M10 68");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST2) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("M10 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST3) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" M10 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST4) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" M10");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST5) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("  M10");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	};



	TEST_CLASS(G28) {
public:
	TEST_METHOD(TEST1) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G28 68");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST2) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G28 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}

	TEST_METHOD(TEST3) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" G28");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	};



	TEST_CLASS(G1) {
public:
	TEST_METHOD(TEST1) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X105.48 Y63.48 A 0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST2) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X46 . 29 Y65.68 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST3) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X100.73 Y63.62 A0 G1 X100.73 Y63.62 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST4) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X15E7.50 Y10F7.50 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST5) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X109.92 Y65.584 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST6) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X109.2 Y65.84 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST7) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X-2.7 Y66.56 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST8) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1  X114.36 Y66.93 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST9) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand(" G1 X-120.15 Y-60.40 A0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST10) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X-120.15 Y-60.40 A0 ");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	TEST_METHOD(TEST11) {
		//create your testinputstruct here in beginning
		GcodeParser parser;
		CommandStruct cmdres = parser.parseCommand("G1 X7.50 Y107.50 A0 M4 0");
		Assert::AreEqual(false, cmdres.isLegal);
		//NOTE
		/*to compare enum commandWords we must enforce the enums into integer first before compare*/
		parser.clearTokens();
	}
	};
}